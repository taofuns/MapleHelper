//
//  ContentView.swift
//  MapleHelper
//
//  Created by Leon on 7/30/22.
//

import SwiftUI


struct ChooseView: View {
    
    var textContent: String
    var chooseContent: Array<Int>
    @Binding var selection: Int
    
    var body: some View{
        
        Section(){
            HStack{
                Text(textContent)
                Spacer()
                Text("\(selection)")
                    .foregroundColor(.pink)
                    .font(.title3)
            }
            Picker("", selection: $selection){
                ForEach(chooseContent,id: \.self){
                    Text("\($0)")
                }
            }
            .pickerStyle(.segmented)
            .frame(maxHeight:100)
        }
    }
}

struct ContentView: View {
    
    @State var myEquip = Equippment.begin
    @State var myEquipCopy = Equippment.begin
    @State var finalResult = FinalResult()
    @State var goalLevel = 40
    @State var times:Double = 100000
    
    let levelChose = [30,32,34,36,38]
    let goalChose = [32,34,36,38,40]
    let currentFailChose = Array<Int>(0..<5)
    let ctsFailChose = Array<Int>(0..<6)
    
    @State var isShow = false
    @FocusState var isFocused
    @State var isExpanded = true
    @State var isActive = false
    
    
    var body: some View {
        
        NavigationView{
            Form{
                
                ChooseView(textContent: "当前装备等级",  chooseContent: levelChose, selection: $myEquip.level)
                
                ChooseView(textContent: "当前超越失败次数", chooseContent: currentFailChose, selection: $myEquip.currentFailure)
                
                if myEquip.currentFailure != 0 {
                    ChooseView(textContent: "最近连续失败次数",  chooseContent: ctsFailChose.filter{$0<=myEquip.currentFailure}, selection: $myEquip.ctsFallure)
                        .animation(.default, value: myEquip.currentFailure)
                }
                
                ChooseView(textContent: "希望将装备等级超越到", chooseContent: goalChose.filter{$0>myEquip.level}, selection: $goalLevel)
                    .animation(.default, value: myEquip.level)
                
                Section{
                    HStack{
                        Text("每件肥料市场价")
                        TextField("", value: $myEquip.equipPrice,format: .number)
                            .focused($isFocused)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .foregroundColor(.pink)
                            .font(.title3)
                    }
                }
                
                
                Section{
                    DisclosureGroup(isExpanded: $isExpanded){
                        Slider(value: $times, in: 1...1000000,step: 1)
                        
                    }label: {
                        Text("模拟\(times.formatted(.number))次")
                            .onLongPressGesture {
                                times = 100000
                            }
                    }
                    
                    
                }
                
                Section{
                    
                    
                    NavigationLink(isActive:$isActive){
                        
                        
                        
                        ResultView(finalResult: $finalResult)
                            .navigationTitle("结果报告")
                            .navigationBarTitleDisplayMode(.inline)
                            .onAppear{
                                
                                finalResult.reset()
                                finalResult.multiSurpass(myEquip, times: Int(times), goalLevel: goalLevel)
                                
                                if UIDevice.current.userInterfaceIdiom == .pad{
                                    isActive = false
                                }
                                
                            }
                        
                        
                    }label: {
                        Button{
                            print("success")
                        }label: {
                            HStack{
                                ProgressView()
                                    .progressViewStyle(.circular)
                                    .opacity(isActive ? 1 : 0 )
                                
                                Spacer()
                                Text("开始超越")
                                Spacer()
                            }
                        }
                        
                    }
                    
                    
                    
                    //                    Button{
                    //                        finalResult.multiSurpass(myEquip, times: Int(times), goalLevel: goalLevel)
                    //                        isShow = true
                    //                        print("success")
                    //
                    //                    }label: {
                    //                        HStack{
                    //                            Spacer()
                    //                            Text("开始超越")
                    //                            Spacer()
                    //                        }
                    //                }
                    
                    
                }
                
                
                
            }
            .animation(.default, value: myEquip.currentFailure == 0)
            .sheet(isPresented: $isShow,onDismiss: didDismiss){
                ResultView(finalResult: $finalResult)
            }
            .navigationTitle("「 超越⚡︎模拟器 」")
            .navigationBarTitleDisplayMode(.inline)
            .padding(.vertical)
            .toolbar{
                ToolbarItemGroup(placement: .keyboard){
                    Button("关闭键盘"){
                        isFocused = false
                    }
                }
            }
        }
    }
    
    
    
    
    
    func didDismiss(){
        finalResult.reset()
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
