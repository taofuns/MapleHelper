//
//  Data.swift
//  MapleHelper
//
//  Created by Leon on 7/30/22.
//

import Foundation

struct Equippment{
    let maxLevel = 40
    let maxFailure = 5
    let extraLuck = 5
    let surpassFee = 50000000
    var surpassNumber = 0
    var surpassCost = 0
    var level: Int
    var equipPrice: Int
    var currentFailure: Int
    var ctsFallure: Int
    let successRate = 50
    
    var latestInfo = ""
    
    var actualRate:Int{
        if successRate + ctsFallure*5 <= 70{
            return successRate + ctsFallure*5
        } else{
            return 70
        }
        
    }
    
    
    mutating func surpass(){
        surpassNumber += 1
        surpassCost = surpassCost + surpassFee + equipPrice
        let luck = Int.random(in: 1...100)
        if luck <= actualRate{
            level += 2
            ctsFallure = 0
            latestInfo = "超越成功,当前等级：\(level)，累计超越失败次数：\(currentFailure)"
        }else{
            ctsFallure += 1
            currentFailure += 1
            latestInfo = "超越成功,当前等级：\(level)，累计超越失败次数：\(currentFailure)"
        }
    }
    
    mutating func surpassTo(_ goalLevel:Int){
        
        while currentFailure < maxFailure{
            if level == maxLevel{
                latestInfo = "已超满，无法继续超越"
                break
            }else{
                surpass()
            }
        }
        
    }
    
    static let begin = Equippment(level: 30, equipPrice: 360_000_000, currentFailure: 0, ctsFallure: 0)
    
    
    
}


struct FinalResult{
    
    struct Result{
        var level = 32
        var currentFailure = 4
        var surpassNumber = 2
        var cost = 0
    }
    
    var result = Result()
    var resultSet = [Result]()
    var myEquipCopy = Equippment.begin
    
    
    var costSet = [Int]()
    var levelSet = [Int]()
    var surpassNumberSet = [Int]()
    var currentFailureSet = [Int]()
    var level40CostSet = [Int]()
    var level38CostSet = [Int]()
    var level36CostSet = [Int]()
    var level34CostSet = [Int]()
    var level32CostSet = [Int]()
    var level30CostSet = [Int]()
    
    var level40Fail0Set = [Int]()
    var level40Fail1Set = [Int]()
    var level40Fail2Set = [Int]()
    var level40Fail3Set = [Int]()
    var level40Fail4Set = [Int]()
    
    
    
    var avgCost = 0
    var level40Times:Double{
        var i = 0.0
        for item in levelSet{
            if item == 40{
                i += 1
            }
        }
        return i
    }
    
    var level38Times:Double{
        var i = 0.0
        for item in levelSet{
            if item == 38{
                i += 1
            }
        }
        return i
    }
    
    var level36Times:Double{
        var i = 0.0
        for item in levelSet{
            if item == 36{
                i += 1
            }
        }
        return i
    }
    
    var level34Times:Double{
        var i = 0.0
        for item in levelSet{
            if item == 34{
                i += 1
            }
        }
        return i
    }
    
    var level32Times:Double{
        var i = 0.0
        for item in levelSet{
            if item == 32{
                i += 1
            }
        }
        return i
    }
    
    var level30Times:Double{
        var i = 0.0
        for item in levelSet{
            if item == 30{
                i += 1
            }
        }
        return i
    }
    
    
    mutating func multiSurpass(_ myEquip:Equippment,times:Int,goalLevel:Int){
        for _ in 1...times{
            myEquipCopy = myEquip
            myEquipCopy.surpassTo(goalLevel)
            result.level = myEquipCopy.level
            result.currentFailure = myEquipCopy.currentFailure
            result.cost = myEquipCopy.surpassCost
            result.surpassNumber = myEquipCopy.surpassNumber
            resultSet.append(result)
            costSet.append(myEquipCopy.surpassCost)
            switch myEquipCopy.level{
            case 40:
                level40CostSet.append(myEquipCopy.surpassCost)
                switch myEquipCopy.currentFailure{
                case 0:level40Fail0Set.append(myEquipCopy.currentFailure)
                case 1:level40Fail1Set.append(myEquipCopy.currentFailure)
                case 2:level40Fail2Set.append(myEquipCopy.currentFailure)
                case 3:level40Fail3Set.append(myEquipCopy.currentFailure)
                case 4:level40Fail4Set.append(myEquipCopy.currentFailure)
                default: print("no")
                }
                
            case 38: level38CostSet.append(myEquipCopy.surpassCost)
            case 36: level36CostSet.append(myEquipCopy.surpassCost)
            case 34: level34CostSet.append(myEquipCopy.surpassCost)
            case 32: level32CostSet.append(myEquipCopy.surpassCost)
            case 30: level30CostSet.append(myEquipCopy.surpassCost)
            default: print("no")
            }
            levelSet.append(myEquipCopy.level)
            surpassNumberSet.append(myEquipCopy.surpassNumber)
            currentFailureSet.append(myEquipCopy.currentFailure)
        }
        
        avgCost = costSet.reduce(0,+) / costSet.count
    }
    
    mutating func reset(){
        avgCost = 0
        costSet = [Int]()
        levelSet = [Int]()
        surpassNumberSet = [Int]()
        currentFailureSet = [Int]()
        level40CostSet = [Int]()
        level38CostSet = [Int]()
        level36CostSet = [Int]()
        level34CostSet = [Int]()
        level32CostSet = [Int]()
        level30CostSet = [Int]()
        level40Fail0Set = [Int]()
        level40Fail1Set = [Int]()
        level40Fail2Set = [Int]()
        level40Fail3Set = [Int]()
        level40Fail4Set = [Int]()
    }
    
    static var example = FinalResult()
    
}
