//
//  ResultView.swift
//  MapleHelper
//
//  Created by Leon on 7/30/22.
//

import SwiftUI

struct ResultView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var finalResult: FinalResult
    var result = (level:32,currentFailure:4,times:2,cost:0)
    @State var showDetail = false
    
    var body: some View {
        
        
        VStack {
            List{
                Section{
                    Text("累计模拟：\(finalResult.levelSet.count)次")
                    Text("平均花费：\(finalResult.avgCost)")
                }
                .font(.body.weight(.bold))
                
                if finalResult.level40Times != 0{
                    Section("最终超满至40级,共计\(Int(finalResult.level40Times))次"){
                        VStack{
                            HStack{
                                Image(systemName: "40.square")
                                    .font(.largeTitle)
                                    .foregroundColor(.pink)
                                VStack(alignment: .leading){
                                    ProgressView(value: finalResult.level40Times/Double(finalResult.levelSet.count)).progressViewStyle(.linear)
                                    Text("占比\(finalResult.level40Times/Double(finalResult.levelSet.count),format:.percent.precision(.fractionLength(2))),平均花费\(finalResult.level40CostSet.reduce(0,+) / Int(finalResult.level40Times))")
                                }
                            }
                        }
                        if showDetail{
                            VStack{
                                
                                if finalResult.level40Fail0Set.count != 0 {
                                    VStack(alignment: .leading){
                                        Text("最终失败次数为0️⃣,占比:\(Double(finalResult.level40Fail0Set.count)/Double(finalResult.level40CostSet.count),format:.percent.precision(.fractionLength(2)))")
                                        ProgressView(value: Double(finalResult.level40Fail0Set.count)/Double(finalResult.level40CostSet.count))
                                            .progressViewStyle(LinearProgressViewStyle(tint: .orange))
                                    }
                                    .padding(.vertical)
                                }
                                
                                if finalResult.level40Fail1Set.count != 0 {
                                    VStack(alignment: .leading){
                                        Text("最终失败次数为1️⃣,占比:\(Double(finalResult.level40Fail1Set.count)/Double(finalResult.level40CostSet.count),format:.percent.precision(.fractionLength(2)))")
                                        ProgressView(value: Double(finalResult.level40Fail1Set.count)/Double(finalResult.level40CostSet.count))
                                            .progressViewStyle(LinearProgressViewStyle(tint: .orange))
                                    }
                                    .padding(.bottom)
                                }
                                
                                if finalResult.level40Fail2Set.count != 0 {
                                    VStack(alignment: .leading){
                                        Text("最终失败次数为2️⃣,占比:\(Double(finalResult.level40Fail2Set.count)/Double(finalResult.level40CostSet.count),format:.percent.precision(.fractionLength(2)))")
                                        ProgressView(value: Double(finalResult.level40Fail2Set.count)/Double(finalResult.level40CostSet.count))
                                            .progressViewStyle(LinearProgressViewStyle(tint: .orange))
                                    }
                                    .padding(.bottom)
                                }
                                
                                if finalResult.level40Fail3Set.count != 0 {
                                    VStack(alignment: .leading){
                                        Text("最终失败次数为3️⃣,占比:\(Double(finalResult.level40Fail3Set.count)/Double(finalResult.level40CostSet.count),format:.percent.precision(.fractionLength(2)))")
                                        ProgressView(value: Double(finalResult.level40Fail3Set.count)/Double(finalResult.level40CostSet.count))
                                            .progressViewStyle(LinearProgressViewStyle(tint: .orange))
                                    }
                                    .padding(.bottom)
                                }
                                
                                if finalResult.level40Fail4Set.count != 0 {
                                    VStack(alignment: .leading){
                                        Text("最终失败次数为4️⃣,占比:\(Double(finalResult.level40Fail4Set.count)/Double(finalResult.level40CostSet.count),format:.percent.precision(.fractionLength(2)))")
                                        ProgressView(value: Double(finalResult.level40Fail4Set.count)/Double(finalResult.level40CostSet.count))
                                            .progressViewStyle(LinearProgressViewStyle(tint: .orange))
                                    }
                                    .padding(.bottom)
                                }
                                
                                
                            }
                        }
                    }
                    .onTapGesture{
                        showDetail.toggle()
                    }
                }
                
                
                if finalResult.level38Times != 0{
                    Section("最终超越至38级,共计\(Int(finalResult.level38Times))次"){
                        VStack{
                            HStack{
                                Image(systemName: "38.square")
                                    .font(.largeTitle)
                                    .foregroundColor(.pink)
                                VStack(alignment: .leading){
                                    ProgressView(value: finalResult.level38Times/Double(finalResult.levelSet.count)).progressViewStyle(.linear)
                                    Text("占比\(finalResult.level38Times/Double(finalResult.levelSet.count),format:.percent.precision(.fractionLength(2))),平均花费\(finalResult.level38CostSet.reduce(0,+) / Int(finalResult.level38Times))")
                                }
                            }
                        }
                    }
                }
                
                if finalResult.level36Times != 0{
                    Section("最终超越至36级,共计\(Int(finalResult.level36Times))次"){
                        VStack{
                            HStack{
                                Image(systemName: "36.square")
                                    .font(.largeTitle)
                                    .foregroundColor(.pink)
                                VStack(alignment: .leading){
                                    ProgressView(value: finalResult.level36Times/Double(finalResult.levelSet.count)).progressViewStyle(.linear)
                                    Text("占比\(finalResult.level36Times/Double(finalResult.levelSet.count),format:.percent.precision(.fractionLength(2))),平均花费\(finalResult.level36CostSet.reduce(0,+) / Int(finalResult.level36Times))")
                                }
                            }
                        }
                    }
                }
                
                if finalResult.level34Times != 0{
                    Section("最终超越至34级,共计\(Int(finalResult.level34Times))次"){
                        VStack{
                            HStack{
                                Image(systemName: "34.square")
                                    .font(.largeTitle)
                                    .foregroundColor(.pink)
                                VStack(alignment: .leading){
                                    ProgressView(value: finalResult.level34Times/Double(finalResult.levelSet.count)).progressViewStyle(.linear)
                                    Text("占比\(finalResult.level34Times/Double(finalResult.levelSet.count),format:.percent.precision(.fractionLength(2))),平均花费\(finalResult.level34CostSet.reduce(0,+) / Int(finalResult.level34Times))")
                                }
                            }
                        }
                    }
                }
                
                if finalResult.level32Times != 0{
                    Section("最终超越至32级,共计\(Int(finalResult.level32Times))次"){
                        VStack{
                            HStack{
                                Image(systemName: "32.square")
                                    .font(.largeTitle)
                                    .foregroundColor(.pink)
                                VStack(alignment: .leading){
                                    ProgressView(value: finalResult.level32Times/Double(finalResult.levelSet.count)).progressViewStyle(.linear)
                                    Text("占比\(finalResult.level32Times/Double(finalResult.levelSet.count),format:.percent.precision(.fractionLength(2))),平均花费\(finalResult.level32CostSet.reduce(0,+) / Int(finalResult.level32Times))")
                                }
                            }
                        }
                    }
                }
                
                if finalResult.level30Times != 0{
                    Section("超越全部失败停在30级,共计\(Int(finalResult.level30Times))次"){
                        VStack{
                            HStack{
                                Image(systemName: "30.square")
                                    .font(.largeTitle)
                                    .foregroundColor(.pink)
                                VStack(alignment: .leading){
                                    ProgressView(value: finalResult.level30Times/Double(finalResult.levelSet.count)).progressViewStyle(.linear)
                                    Text("占比\(finalResult.level30Times/Double(finalResult.levelSet.count),format:.percent.precision(.fractionLength(2))),平均花费\(finalResult.level30CostSet.reduce(0,+) / Int(finalResult.level30Times))")
                                }
                            }
                        }
                    }
                }
                
                
                
                
            }
            .animation(.default, value: showDetail)
            //            Button("关闭"){
            //                dismiss()
            //            }
            //            .padding()
        }
        
        
        
        
        
    }
}



struct ResultView_Previews: PreviewProvider {
    static var previews: some View {
        ResultView(finalResult: .constant(FinalResult()))
    }
}
