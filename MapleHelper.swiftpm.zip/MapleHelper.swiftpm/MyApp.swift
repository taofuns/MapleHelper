//
//  MapleHelperApp.swift
//  MapleHelper
//
//  Created by Leon on 7/30/22.
//

import SwiftUI

@main
struct MapleHelperApp: App {
    var body: some Scene {
        
        WindowGroup{
            ContentView()
        }
        
    }
}
